window.addEventListener("load", Inicializar);
var divContenedor;
var btnModificar;
var btnCancelar;

function Inicializar(){
    var btnGuardar = $("btnGuardar");
    var btnHarcodear = $("btnHarcodear");
    var btnAbrir = $("btnAbrir");
    var btnCerrar = $("btnCerrar");
    btnModificar = $("btnModificar");
    divContenedor = $("DivContenedor");

    
    btnGuardar.addEventListener("click",CargarTabla);
    btnHarcodear.addEventListener("click",Harcodear);

    btnAbrir.addEventListener("click",Abrir);
    btnCerrar.addEventListener("click",Cerrar);

    btnModificar.addEventListener("click",Modificar);

    divContenedor.hidden = true;
}



function Editar(e){
    e.preventDefault();
    btnModificar.hidden = false;
    $("btnGuardar").hidden = true;

    var childs = e.target.parentNode.parentNode.children;
  
    $("txtName").value = childs[0].innerText;
    $("txtApellido").value = childs[1].innerText;

    divContenedor.hidden = false;
}
function Modificar(e)
{
    CargarTabla();
    Borrar(e);
}



function CargarTabla()
{
    var nombre = $("txtName").value;
    var apellido = $("txtApellido").value;
    console.log(nombre);
    if(nombre == "" || apellido == "")
    {
        $("txtName").className="Error";
        $("txtApellido").className="Error"; 
    }
    else
    {    
        $("txtName").className="sinError";
        $("txtApellido").className="sinError"; 
        var texto = "<tr><td>";
        texto += nombre;
        texto += "</td><td>";
        texto += apellido;
        texto += "</td><td>";
        texto += "<a href=\"\" onclick=\"Borrar(event)\" >borrar</a>";
        texto += "<a href=\"\" onclick=\"Editar(event)\" >editar</a>";
        texto += "</td></tr>";
        $("tabBody").innerHTML += texto;
        
        Cerrar();
    }  
}

function Borrar(e){
    e.preventDefault();//borra funciones por default
    console.log(e.target.parentNode.parentNode);
    var parent = e.target.parentNode.parentNode
    parent.innerHTML = "";
}



function Abrir()
{
    divContenedor.className = "popup";
    divContenedor.hidden = false;
}
function Cerrar()
{
    divContenedor.hidden = true;
}

function Harcodear()
{
    var i;
    var texto = "";
    for(i=0;i<5;i++)
    {
        texto += "<tr><td>";
        texto += "nombre " + i;
        texto += "</td><td>";
        texto += "apellido " + i;
        texto += "</td><td>";
        texto += "<a href=\"\" onclick=\"Borrar(event)\" >borrar</a>";
        texto += "<a href=\"\" onclick=\"Editar(event)\" >editar</a>";
        texto += "</td></tr>";
    }
    
    $("tabBody").innerHTML += texto;
}
function $(id)
{
    return document.getElementById(id);
}
