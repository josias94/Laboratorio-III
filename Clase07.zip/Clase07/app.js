window.addEventListener("load",inicializarEventos,false);

function inicializarEventos(){
    document.getElementById("Paises").addEventListener("click",as,false);
}




var array = {}
array.TraerCiudades = function(data, pais = "Chile")
{
    return data.filter(x => x.pais == pais).map(x => x.ciudad);
}

array.TraerPais = function(data){
    return data.map(x=> x.pais);
}

//console.log(array.TraerCiudades(data));
console.log(array.TraerPais(data));