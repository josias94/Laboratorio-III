$("document").ready(function(){
    //console.log($("#parrafo").html("algo"));

    $("#btn").click(function(){
        $.get("http://localhost:3000/personas",function(data,status){
            for(var i =0;i <data.length;i++){
                alert(data +"\nstatus:" +status);
            }    
        });
    });

    $json = "algun json"
    $("btn2").click(function(){
        $.post("http://localhost:3000/personas",json,function(data,status){
        });
    });

    $("#txt").val("Nuevo valor");
    $id = $("#txt").attr("id","nuevo");
    console.log($id);
})


/*
window.addEventListener("load", function(){
    //console.log(document.getElementById("parrafo").innerHTML);
    //console.log($("btn"));//por tag
    //console.log($("#btn"));//por ID
    //por clase con #
    //console.log($("#parrafo").html());
    console.log($("#parrafo").html("algo"));
    //document.getElementById("btn").addEventListern("Click",Saludar);
    

});
*/

function Saludar()
{
    alert("Hola");
}



