window.addEventListener("load", Inicializar);
var btnModificar;
var btnCancelar;

function Inicializar(){
    var btnHarcodear = $("btnHarcodear");
    var btnAbrir = $("btnAbrir");
    btnModificar = $("btnModificar");

    btnHarcodear.addEventListener("click",Obtenerjson);
    btnAbrir.addEventListener("click",CrearDivLog);
}



function Editar(e){
    e.preventDefault();
    btnModificar.hidden = false;
    $("btnGuardar").hidden = true;

    var childs = e.target.parentNode.parentNode.children;

    $("txtName").value = childs[0].innerText;
    $("txtApellido").value = childs[1].innerText;

    divContenedor.hidden = false;
}
function Modificar(e)
{
    CargarTabla();
    Borrar(e);
}




function Borrar(e){
    e.preventDefault();//borra funciones por default
    console.log(e.target.parentNode.parentNode);
    var parent = e.target.parentNode.parentNode.parentNode;
    parent.removeChild(e.target.parentNode.parentNode);
}

function Obtenerjson()
{
  var json = [{"nombre":"aaaaa","apellido":"bbbbb"},{"nombre":"ccccc","apellido":"ddddd"}];
  var a = JSON.stringify(json);
  var lista = JSON.parse(a);
  lista.forEach(item => {
    CargarTabla(item);
  });
}

function CargarTabla(json)
{    
    var tr = $Create("tr");

    var td = $Create("td");
    var nombre = $CreateText(json.nombre);
    td.appendChild(nombre);

    var td2 = $Create("td");
    var apellido = $CreateText(json.apellido);
    td2.appendChild(apellido);

    var td3 = $Create("td");
    var aBorrar = $Create("a");
    var aEditar = $Create("a");

    aBorrar.setAttribute("href","\"\"");
    aBorrar.setAttribute("onclick","Borrar(event)");
    aBorrar.appendChild($CreateText("Borrar "));
    td3.appendChild(aBorrar);

    aEditar.setAttribute("href","\"\"");
    aEditar.setAttribute("onclick","Editar(event)");
    aEditar.appendChild($CreateText("Editar"));
    td3.appendChild(aEditar);
    
    tr.appendChild(td);
    tr.appendChild(td2);
    tr.appendChild(td3);
    $("tabBody").appendChild(tr);
}

function CrearDivLog()
{
    var DivContenedor = $("DivContenedor");

    var div = $Create("div");
    div.className = "popup";

    var jsonNombre =  {"placeholder": "Ingrese Nombre:","type":"Text","id":"IdNombre"};
    var jsonNombreL =  {"text": "Nombre:","for":"IdNombre","id":"IdLabelNombre"};

    var jsonApellido =  {"placeholder": "Ingrese Apellido:","type":"Text","id":"IdApellido"};
    var jsonApellidoL =  {"text": "Apellido:","for":"IdApellido","id":"IdLabelApellido"};
    
    var button = $Create("input");
    button.setAttribute("type","button");
    button.setAttribute("onclick","AltaPersona()");
    button.value = "Guardar";   

    div.appendChild(CrearLabelFor(jsonNombreL));
    div.appendChild($Create("br"));
    div.appendChild(CrearInputText(jsonNombre));
    div.appendChild($Create("br"));
    div.appendChild(CrearLabelFor(jsonApellidoL));
    div.appendChild($Create("br"));
    div.appendChild(CrearInputText(jsonApellido));
    div.appendChild($Create("br"));
    div.appendChild(button);
    DivContenedor.appendChild(div);
}

function AltaPersona()
{
    var json = {"nombre":$("IdNombre").value,"apellido": $("IdApellido").value};
    CargarTabla(json);
}

function CrearInputText(json)
{
    var inputText = $Create("input");
    inputText.setAttribute("type",json.type);
    inputText.id = json.id;
    inputText.placeholder = json.placeholder;
    return inputText;
}
function CrearLabelFor(json)
{
    var label = $Create("label");
    var texto = $CreateText(json.text); 
    label.appendChild(texto); 
    label.id = json.id;
    label.for = json.for;
    return label;
}


function $(id)
{
    return document.getElementById(id);
}
function $Create(id)
{
    return document.createElement(id);
}
function $CreateText($text)
{
    return document.createTextNode($text); 
}