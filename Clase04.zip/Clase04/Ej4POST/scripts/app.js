window.addEventListener("load",inicializarEventos,false);

function inicializarEventos(){
    document.getElementById("btnCargar").addEventListener("click",manejarSubmit,false);
}

function manejarSubmit(e){
    /*desactivamos el manejador por default*/
    e.preventDefault();
    cargarPersona();
}

function cargarPersona(){
    var xhr = new XMLHttpRequest();
    
    xhr.onreadystatechange = function(){
        document.getElementById("info").innerHTML = "<img src = 'Imagenes/preloader.gif'>"
        if(this.readyState == 4){
            if(this.status == 200){
                document.getElementById("info").innerHTML = this.responseText;
            }
            else{
                document.getElementById("info").innerHTML = "Error: " + this.status + " " + this.statusText;
            }
        }
    }
    var frm = document.getElementById("frmPersona");

    var data = new FormData(frm);
    xhr.open("POST", "pagina1.php", true); 
    //xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
    xhr.setRequestHeader("X-Requested-With","XMLHTTPRequest");
    xhr.send(data);
}

function leerDatos(){
    var cadena = "";
    var nombre = document.getElementById("txtNombre").value;
    var edad = document.getElementById("txtEdad").value;
    cadena += "nombre=" + encodeURIComponent(nombre) + "&edad=" + encodeURIComponent(edad);
    return cadena;
}
