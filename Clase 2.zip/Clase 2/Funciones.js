window.addEventListener("load", Cargar);


// var numero1;
// var numero2;

function Cargar(){
    var btnSumar = document.getElementById("btnsumar");
    var btnSumarYGuardar = document.getElementById("btnSumarYguardar");

    // document.getElementById("inpNum1").addEventListener("input",tomartexto);
    // document.getElementById("inpNum2").addEventListener("input",tomartexto2);
    // document.getElementById("inpNum2").addEventListener("input",settext);
    
    // btnSumar.addEventListener("click",Sumar);
    // btnSumarYGuardar.addEventListener("click",SumarYGuardar);
}

function $(id)
{
    return document.getElementById(id);
}

// function tomartexto()
// {
//     numero1 = this.value;
//     console.log(numero1);
// }
// function tomartexto2()
// {
//     numero2 = this.value;
//     console.log(numero2);
// }
// function settext()
// {
//     $("txtResultado").value = parseInt(numero1) + parseInt(numero2);
// }
function Sumar()
{
    console.log("Entro sumar");
    var num1 = document.getElementById("inpNum1").value;
    var num2 = document.getElementById("inpNum2").value;  
    document.getElementById("txtResultado").value = parseInt(num1) + parseInt(num2);
}

function SumarYGuardar()
{
    console.log("Entro sumar y guardar");
    var num1 = document.getElementById("inpNum1").value;
    var num2 = document.getElementById("inpNum2").value;   
    var texto = "<tr><td>";
    texto += num1;
    texto += "</td><td>";
    texto += num2;
    texto += "</td><td>";
    texto += parseInt(num1) + parseInt(num2);
    texto += "</td></tr>";

    document.getElementById("tabBody").innerHTML += texto;

}
// function Mostrar()
// {
//     var name = document.getElementById("txtUsr").value;
//     var password = document.getElementById("txtPass").value;
//     var cheak = document.getElementById("cheUsrPass");
//     console.log("Mostro");
    
//     console.log("Nombre: " + name + " Password: " + password);
// }

// // document.getElementById("row").innerHTML("ALGO")