var numero = [1,2,6,4,5,3];

// var arrayCuadrado = [];
// for (let index = 0; index < numero.length; index++)
// {
//     arrayCuadrado.push(numero[index]*numero[index]); 
// }
var arrayCuadrado = numero.map(numero => numero*numero);

// var arraymenores = [];
// for (let index = 0; index < numero.length; index++)
// {
//     if(numero[index]<4)
//         arraymenores.push(numero[index]); 
// }
var arraymenores = numero.filter(numero => numero<4);


// var suma = 0;
// for (let index = 0; index < numero.length; index++)
// {
//     suma += numero[index]; 
// }
var suma=numero.reduce( (previo , actual) => previo + actual, 0);


console.log(arrayCuadrado);
console.log(arraymenores);
console.log(suma);