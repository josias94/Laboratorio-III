if(localStorage){
    if(localStorage.token){
        validateUser(localStorage.token);
    }
    else{
        alert("No tiene permisos suficientes");
        window.location.replace("http://localhost:3000/accessdenied.html");
    }
}

window.onload = function(){
    $("#btnLogoff").click (function(e){
        localStorage.removeItem("token");
        window.location.replace("http://localhost:3000");
    })
    // this.document.getElementById("btnLogIn").addEventListener();
}

function validateUser(token){
    xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function(){
        if(this.readyState == 4){
            if(this.status == 200){
                if(xhr.responseText == "OK"){
                    //window.location.replace("http://localhost:3000/admin.html");
                }
            }
            else{
                alert("No tiene permisos suficientes");
                window.location.replace("http://localhost:3000/accessdenied.html");
            }
        }
    };
    xhr.open("POST","http://localhost:3000/validate",false);
    xhr.setRequestHeader("authorization",token);
    xhr.send("");

}