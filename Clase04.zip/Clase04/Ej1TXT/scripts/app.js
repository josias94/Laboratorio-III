window.addEventListener("load",inicializarEventos,false);

function inicializarEventos(){
    document.getElementById("btnCargar").addEventListener("click",traerTexto,false);
}

function traerTexto(){
    var xhr = new XMLHttpRequest();
    /*funcion que se ejecuta cada ver que cambie de estado readyState*/
    /*
     0 no fue abierto,
     1 no fue enviado,
     2 error en servidor,
     3 aun no termino,
     4 termino
    */
    xhr.onreadystatechange = function(){
        if(this.readyState == 4 && this.status == 200){
            /*responseText es lo que trae del servidor*/
            document.getElementById("info").innerHTML = this.responseText;

        }
    }
    /*true = asincrona*/
    xhr.open("GET", "archivo.txt", true); 
    xhr.send();
}