window.onload=()=>{
  var element = document.createElement("p");
  var testo = document.createTextNode("Hola mundo");
  elemento.appendChild(testo);
  var bodi = document.getElementsByTagName("body");
  bodi.appendChild(element)
};
