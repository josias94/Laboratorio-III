window.addEventListener("load", Cargar);

function Cargar(){
    var btnEnviar = $("btnEnviar");
    var btnHarcodear = $("btnHarcodear");
    btnEnviar.addEventListener("click",CargarTabla);
    btnHarcodear.addEventListener("click",Harcodear);
    
}

function CargarTabla()
{
    var nombre = $("txtName").value;
    var apellido = $("txtApellido").value;
    console.log(nombre);
    if(nombre == "" || apellido == "")
    {
        $("txtName").className="Error";
        $("txtApellido").className="Error"; 
    }
    else
    {    
        $("txtName").className="sinError";
        $("txtApellido").className="sinError"; 
        var texto = "<tr><td>";
        texto += nombre;
        texto += "</td><td>";
        texto += apellido;
        texto += "</td><td>";
        texto += "<a href=\"\" onclick=\"Borrar(event)\" >borrar</a>";
        texto += "</td></tr>";
        $("tabBody").innerHTML += texto;
    }
}

function Borrar(e){
    e.preventDefault();//borra funciones por default
    //console.log(e);
    //console.log(e.target);
    console.log(e.target.parentNode.parentNode);
    var parent = e.target.parentNode.parentNode
    parent.innerHTML = "";
}


function Harcodear()
{
    var i;
    var texto = "";
    for(i=0;i<5;i++)
    {
        texto += "<tr><td>";
        texto += "nombre " + i;
        texto += "</td><td>";
        texto += "apellido " + i;
        texto += "</td><td>";
        texto += "<a href=\"\" onclick=\"Borrar(event)\" >borrar</a>";
        texto += "</td></tr>";
    }
    
    $("tabBody").innerHTML += texto;
}
function $(id)
{
    return document.getElementById(id);
}
