<?php
/*
if($_POST){
    $nombre = $_POST["nombre"];
    $edad = $_POST["edad"];
    $respuesta = $nombre. " ".$edad;
    //sleep(10);
    echo $respuesta;
}
*/
$persona = "{ \"nombre\":\"Juan\",\"edad\":\"32\"}";

echo $persona;

/*
se tiene que poder leer el json y despues tirar el array de objetos y de el array crear una tabla en html
mockarru
*/

?>