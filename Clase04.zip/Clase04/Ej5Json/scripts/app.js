window.addEventListener("load",inicializarEventos,false);

function inicializarEventos(){
    document.getElementById("btnCrear").addEventListener("click",crearObjeto,false);
}

function manejarSubmit(e){
    /*desactivamos el manejador por default*/
    e.preventDefault();
    cargarPersona();
}

function crearObjeto(){
/*
    var cadena = '{"nombre":"Juan","edad":"23"}';
    console.log(cadena);


    var persona = JSON.parse(cadena);
    console.log(persona);
    document.getElementById("info").innerHTML = persona.nombre;
    document.getElementById("info").innerHTML += " ";
    document.getElementById("info").innerHTML += persona.edad;
*/

    var xhr = new XMLHttpRequest();
    
    xhr.onreadystatechange = function(){
        //document.getElementById("info").innerHTML = "<img src = 'Imagenes/preloader.gif'>"
        if(this.readyState == 4 && this.status == 200){
            var persona = JSON.parse(this.responseText);
            document.getElementById("info").innerHTML = "Nombre:" + persona.nombre + " Edad: " + persona.edad;
        }
    }
    xhr.open("GET", "servidor.php", true); 
    xhr.send();


    /*
    var xhr = new XMLHttpRequest();
    
    xhr.onreadystatechange = function(){
        document.getElementById("info").innerHTML = "<img src = 'Imagenes/preloader.gif'>"
        if(this.readyState == 4){
            if(this.status == 200){
                document.getElementById("info").innerHTML = this.responseText;
            }
            else{
                document.getElementById("info").innerHTML = "Error: " + this.status + " " + this.statusText;
            }
        }
    }
    var frm = document.getElementById("frmPersona");

    var data = new FormData(frm);
    xhr.open("POST", "pagina1.php", true); 
    //xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
    xhr.setRequestHeader("X-Requested-With","XMLHTTPRequest");
    xhr.send(data);
    */
}

function leerDatos(){
    var cadena = "";
    var nombre = document.getElementById("txtNombre").value;
    var edad = document.getElementById("txtEdad").value;
    cadena += "nombre=" + encodeURIComponent(nombre) + "&edad=" + encodeURIComponent(edad);
    return cadena;
}
