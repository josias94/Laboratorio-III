

window.onload = function () {
    this.document.getElementById("titulo").addEventListener("click",Saludar,false);
    this.document.getElementById("titulo").addEventListener("click",CambiarColor,false);
    this.document.getElementById("titulo").addEventListener("mouseover",CambiarTexto,false);
    this.document.getElementById("titulo").addEventListener("click",function(){
        alert("Chau");
    },false);

}


function Saludar()
{
    alert("Hola");
    document.getElementById("titulo").removeEventListener("click",Saludar);
}

function CambiarColor(){
    document.getElementById("titulo").style.color = "red";
}

function CambiarTexto(){
    document.getElementById("titulo").innerHTML = "Cambio texto";
}

