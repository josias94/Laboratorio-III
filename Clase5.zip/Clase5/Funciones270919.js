window.addEventListener("load", Inicializar);
var divContenedor;
var btnModificar;
var btnCancelar;

function Inicializar()
{
  CargarPagina();

  var btnGuardar = $("btnGuardar");
  var btnHarcodear = $("btnHarcodear");
  var btnAbrir = $("btnAbrir");
  var btnCerrar = $("btnCerrar");
  btnModificar = $("btnModificar");
  divContenedor = $("DivContenedor");


  btnGuardar.addEventListener("click",AltaPersona);
  // btnHarcodear.addEventListener("click",Harcodear);
  // btnAbrir.addEventListener("click",Abrir);
  // btnCerrar.addEventListener("click",Cerrar);

  // btnModificar.addEventListener("click",Modificar);


}

function CargarPagina()
{
  var http = new XMLHttpRequest();
  http.open("GET","http://localhost:3000/personas");

  http.onreadystatechange = () =>{
    if(http.status == 200 && http.readyState == 4){
      Obtenerjson(http.responseText);
    }
  }

  http.send();
}

function AltaPersona()
{
  var http = new XMLHttpRequest();
  http.open("POST","http://localhost:3000/nuevaPersona");
  http.setRequestHeader("Content-Type","application/json");

  var json = {"nombre":$("txtName"),"apellido": $("txtApellido"),"fecha":"0","telefono":"0"};

  http.onreadystatechange = () =>
  {
    if(http.status == 200 && http.readyState == 4)
    {
      console.log(http.responseText);
    }
  }

  http.send(JSON.stringify(json));
}


function Obtenerjson(resp)
{
  var lista = JSON.parse(resp);
  lista.forEach(item => {
    CargarTabla(item.nombre,item.apellido);
  });
}

function CargarTabla(nombre, apellido)
{
    if(nombre == "" || apellido == "")
    {
        $("txtName").className="Error";
        $("txtApellido").className="Error";
    }
    else
    {
        $("txtName").className="sinError";
        $("txtApellido").className="sinError";
        var texto = "<tr><td>";
        texto += nombre;
        texto += "</td><td>";
        texto += apellido;
        texto += "</td><td>";
        texto += "<a href=\"\" onclick=\"Borrar(event)\" >borrar</a>";
        texto += "<a href=\"\" onclick=\"Editar(event)\" >editar</a>";
        texto += "</td></tr>";
        $("tabBody").innerHTML += texto;

        Cerrar();
    }
}

function $(id)
{
    return document.getElementById(id);
}
